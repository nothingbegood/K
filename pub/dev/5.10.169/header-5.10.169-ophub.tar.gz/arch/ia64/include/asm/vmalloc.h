#ifndef _ASM_IA64_VMALLOC_H
#define _ASM_IA64_VMALLOC_H

#endif /* _ASM_IA64_VMALLOC_H */
