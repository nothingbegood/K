#ifndef _ASM_H8300_MMU_CONTEXT_H
#define _ASM_H8300_MMU_CONTEXT_H

#include <asm-generic/nommu_context.h>

#endif /* _ASM_H8300_MMU_CONTEXT_H */
