#ifndef _ASM_EMERGENCY_RESTART_H
#define _ASM_EMERGENCY_RESTART_H

#include <asm-generic/emergency-restart.h>

#endif /* _ASM_EMERGENCY_RESTART_H */
