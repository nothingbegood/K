/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (C) 2020-2022 Loongson Technology Corporation Limited
 */
#ifndef _ASM_EXEC_H
#define _ASM_EXEC_H

extern unsigned long arch_align_stack(unsigned long sp);

#endif /* _ASM_EXEC_H */
