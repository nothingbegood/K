/* SPDX-License-Identifier: GPL-2.0 */
static inline void init_mmu(void)
{
}

static inline void init_kio(void)
{
}

#include <asm-generic/nommu_context.h>
